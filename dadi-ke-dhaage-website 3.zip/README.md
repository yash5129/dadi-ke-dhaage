# Dadi ke Dhaage Website

A simple product website for handcrafted hairbows and hair bands.

## Run locally
Open `index.html` in a browser.

## Put it on GitHub Pages
1. Create a new GitHub repository, e.g. `dadi-ke-dhaage`.
2. Upload `index.html`, `style.css`, and the `images` folder.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will give you a public website URL.

## Edit later
- Change product names/prices in `index.html`.
- Replace photos inside `images/`.
- Change the WhatsApp numbers in the `wa.me` links.
